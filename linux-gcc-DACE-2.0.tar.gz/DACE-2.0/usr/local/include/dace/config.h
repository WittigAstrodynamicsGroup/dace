/******************************************************************************
*                                                                             *
* DIFFERENTIAL ALGEBRA CORE ENGINE                                            *
*                                                                             *
*******************************************************************************
*                                                                             *
* Copyright 2016 Politecnico di Milano (2014 Dinamica Srl)                    *
* Licensed under the Apache License, Version 2.0 (the "License");             *
* you may not use this file except in compliance with the License.            *
* You may obtain a copy of the License at                                     *
*                                                                             *
*    http://www.apache.org/licenses/LICENSE-2.0                               *
*                                                                             *
* Unless required by applicable law or agreed to in writing, software         *
* distributed under the License is distributed on an "AS IS" BASIS,           *
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.    *
* See the License for the specific language governing permissions and         *
* limitations under the License.                                              *
*                                                                             *
*******************************************************************************/

/*
 *  config.h
 *
 *  Created on: July 19, 2018
 *      Author: University of Southampton
 */

/*
    This file contains the build time configuration options used for building the DACE library.
*/
/** \addtogroup DACE Core 
 *  @{
 */

#ifndef DINAMICA_CONFIG_H_
#define DINAMICA_CONFIG_H_

#define DACE_MAJOR_VERSION 2
#define DACE_MINOR_VERSION 0
#define DACE_PATCH_VERSION 0

#define DACE_MEMORY_HYBRID 1
#define DACE_MEMORY_STATIC 2
#define DACE_MEMORY_DYNAMIC 3
#define DACE_MEMORY_MODEL DACE_MEMORY_HYBRID
#define DACE_MEMORY_MODEL_STR "HYBRID"

/* #undef WITH_DEBUG */
/* #undef WITH_ALGEBRAICMATRIX */
/* #undef WITH_PTHREAD */

// automatically detected function availability at library build time
/* #undef HAVE_UNDERSCORE_PREFIXED_BESSEL_FUNCTIONS */

// The following limits are only used when *building* the DACE library with DACE_MEMORY_STATIC memory model.
// They are repeated here merely for reference and do not change the available memory in the library
// unless the library is recompiled.
#if DACE_MEMORY_MODEL == DACE_MEMORY_STATIC
    // Maximum order and maximum variables supported independently of each other
/* #undef DACE_STATIC_NOMAX */
/* #undef DACE_STATIC_NVMAX */
    // Maximum number of monomials supported in any NO, NV pair
/* #undef DACE_STATIC_NMMAX */
/* #undef DACE_STATIC_LIAMAX */
    // maximum number of DA variables and memory size
/* #undef DACE_STATIC_VAR_SIZE */
/* #undef DACE_STATIC_MEM_SIZE */
#endif

// On Windows, set the default DACE_API to import from a DLL for dynamic linking
#ifndef DACE_API
    #if defined _WIN32 || defined __CYGWIN__
        #define DACE_API __declspec(dllimport)
    #else
        #define DACE_API
    #endif
#endif

// Define DACE_THREAD_LOCAL decorator for thread local variable storage
#ifdef WITH_PTHREAD
    #ifdef _WIN32
        #define DACE_THREAD_LOCAL __declspec(thread)
    #else
        #define DACE_THREAD_LOCAL __thread
    #endif
#else
    // just treat thread local stuff as normal variables
    #define DACE_THREAD_LOCAL
#endif

/** @}*/
#endif /* DINAMICA_CONFIG_H_ */
