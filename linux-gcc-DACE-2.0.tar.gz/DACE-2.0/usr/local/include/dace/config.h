/******************************************************************************
*                                                                             *
* DIFFERENTIAL ALGEBRA CORE ENGINE                                            *
*                                                                             *
*******************************************************************************
*                                                                             *
* Copyright 2016 Politecnico di Milano (2014 Dinamica Srl)                    *
* Licensed under the Apache License, Version 2.0 (the "License");             *
* you may not use this file except in compliance with the License.            *
* You may obtain a copy of the License at                                     *
*                                                                             *
*    http://www.apache.org/licenses/LICENSE-2.0                               *
*                                                                             *
* Unless required by applicable law or agreed to in writing, software         *
* distributed under the License is distributed on an "AS IS" BASIS,           *
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.    *
* See the License for the specific language governing permissions and         *
* limitations under the License.                                              *
*                                                                             *
*******************************************************************************/

/*
 *  daceaux.h
 *
 *  Created on: July 19, 2018
 *      Author: University of Southampton
 */

/*
    This file contains the build time configuration options used for building the DACE library.
*/
/** \addtogroup DACE Core 
 *  @{
 */

#ifndef DINAMICA_CONFIG_H_
#define DINAMICA_CONFIG_H_

#define DACE_MEMORY_HYBRID 1
#define DACE_MEMORY_STATIC 2
#define DACE_MEMORY_DYNAMIC 3
#define DACE_MEMORY_MODEL DACE_MEMORY_HYBRID
#define DACE_MEMORY_MODEL_STR "HYBRID"

/* #undef WITH_DEBUG */
/* #undef WITH_ALGEBRAICMATRIX */
/* #undef WITH_PTHREAD */

/** @}*/
#endif /* DINAMICA_DACEAUX_H_ */
